<!-- latest jquery-->
    

<!--  jquery validation-->
  

    


 
    <!-- Bootstrap js-->
    <script src="{{asset('assets/js/jquery-3.3.1.min.js')}}"></script>
    <script src="{{asset('assets/js/sidebar-menu.js')}}"></script>
        <script src="{{asset('assets/js/Datepicker1/dist/mc-calendar.min.js')}}"></script>

<script src="{{asset('assets/js/imask.js')}}"></script>
    <script src="{{asset('assets/js/bootstrap.bundle.min.js')}}"></script>

    <!-- feather icon js-->
    <script src="{{asset('assets/js/icons/feather-icon/feather.min.js')}}"></script>
    <script src="{{asset('assets/js/icons/feather-icon/feather-icon.js')}}"></script>

    <!-- Sidebar jquery-->
    
    <script src="{{asset('assets/js/slick.js')}}"></script>

    <!-- Jsgrid js-->
    <script src="{{asset('assets/js/jsgrid/jsgrid.min.js')}}"></script>
    <script src="{{asset('assets/js/jsgrid/griddata-invoice.js')}}"></script>
    <script src="{{asset('assets/js/jsgrid/jsgrid-invoice.js')}}"></script>

    <!-- lazyload js-->
    <script src="{{asset('assets/js/lazysizes.min.js')}}"></script>

    <!--right sidebar js-->
    <!--<script src="{{asset('assets/js/chat-menu.js')}}"></script> -->

    <!--script admin-->
    <script src="{{asset('assets/js/admin-script.js')}}"></script>
    <script>
        $('.single-item').slick({
            arrows: false,
            dots: true
        });
    </script>




<!-- Bootstrap js-->


<!-- feather icon js
<script src="{{asset('assets/js/icons/feather-icon/feather.min.js')}}"></script>
<script src="{{asset('assets/js/icons/feather-icon/feather-icon.js')}}"></script>-->

<!-- Sidebar jquery-->




<!-- Datatable js-->
<script src="{{asset('assets/js/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('assets/js/datatables/custom-basic.js')}}"></script>

<!--Customizer admin-->
<script src="{{asset('assets/js/admin-customizer.js')}}"></script>

<!-- lazyload js-->
<script src="{{asset('assets/js/lazysizes.min.js')}}"></script>

<!--right sidebar js-->
<script src="{{asset('assets/js/chat-menu.js')}}"></script>

<!--script admin-->
<script src="{{asset('assets/js/admin-script.js')}}"></script>

<!--chartist js-->
<script src="{{asset('assets/js/chart/chartist/chartist.js')}}"></script>

<!--chartjs js-->
<script src="{{asset('assets/js/chart/chartjs/chart.min.js')}}"></script>
<!-- lazyload js-->
<script src="{{asset('assets/js/lazysizes.min.js')}}"></script>

<!--peity chart js-->
<script src="{{asset('assets/js/chart/peity-chart/peity.jquery.js')}}"></script>

<!--dashboard custom js-->
<!--<script src="{{asset('assets/js/dashboard/default.js')}}"></script>-->
<!--new-->

 <!-- jquery
		============================================ -->
   
    <!-- bootstrap JS
		============================================ -->
    <script src="{{asset('assets/js/bootstrap.min.js')}}"></script>
    <!-- wow JS
		============================================ -->
    
    <!-- data table JS
		============================================ -->
    <script src="{{asset('assets/js/data-table/bootstrap-table.js')}}"></script>
    <script src="{{asset('assets/js/data-table/tableExport.js')}}"></script>
    <script src="{{asset('assets/js/data-table/data-table-active.js')}}"></script>
    <script src="{{asset('assets/js/data-table/bootstrap-table-editable.js')}}"></script>
    <script src="{{asset('assets/js/data-table/bootstrap-editable.js')}}"></script>
    <script src="{{asset('assets/js/data-table/bootstrap-table-resizable.js')}}"></script>
    <script src="{{asset('assets/js/data-table/colResizable-1.5.source.js')}}"></script>
    <script src="{{asset('assets/js/data-table/bootstrap-table-export.js')}}"></script>
    <!--  editable JS
		============================================ -->


    </body>

    </html>