
		<style>
		#deactive{
	display:none;
	
	
	}
	</style>
		
		
		
		
		
<script>
						function status(){
		
		
		document.getElementById("deactive").style.display="block";
		document.getElementById("active").style.display="none";
	document.getElementById("deactive").style.width="33%";
		
		
		
	}
	function status1(){
		
		
		document.getElementById("active").style.display="block";
		document.getElementById("deactive").style.display="none";
		document.getElementById("active").style.width="33%";
		
	}
					
					
					
					
					</script>