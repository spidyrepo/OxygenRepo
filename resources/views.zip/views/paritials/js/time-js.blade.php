<script>

const myDatePicker = MCDatepicker.create({ 
      el: '#example' 
	  
})
	const myDatePicker1 = MCDatepicker.create({ 
      
	  el:'#example1'
})
	
</script>

