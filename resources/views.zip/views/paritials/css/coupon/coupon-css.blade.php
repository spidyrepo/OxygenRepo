<style>
	#static{
	display:none;
	
	}
	
	#coupon{
	display:none;
	
	}
	#coupon1{
	display:none;
	
	}
	

	
	#percentagediv{
	display:none;
	
	}
	#disamount{
	display:black;
	
	}
	
	#minimumpurchase{
		
		display:none;
		
	}
	#minimumquantity{
		
		display:none;
		
	}
	#discountdiv{
		display:block;
	}
</style>