<style>
.thumb-image{
	width:100px;
}
</style>