<style>
.display{
	table-layout:fixed;
	width:100%;
}
</style>