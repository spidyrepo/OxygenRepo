<style>
body
{
background-image: url('assets/images/banners/bg.jpg');
}
</style>