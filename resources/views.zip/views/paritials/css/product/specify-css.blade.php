  <style>
#more 
{
display: none;
}
</style>