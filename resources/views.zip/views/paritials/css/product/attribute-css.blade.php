<style>
.display{
	table-layout:fixed;
	width:100%;
}

  
#more 
{
display: none;
}
</style>
