<style>

.select2-container--default .select2-selection--multiple {
  background-color: white;
  border: 1px solid #aaaaaa6e;
    border-top-width: 1px;
    border-right-width: 1px;
    border-bottom-width: 1px;
    border-left-width: 1px;
  border-radius: 4px;
  cursor: text;
}
   .color {
  width: 25px !important;
  height: 25px !important;
  border-radius: 50%;
  border: none;
  background-color: transparent;
}
</style>