<style>
	#static{
	display:none;
	
	}
	
	#coupon{
	display:none;
	
	}
	#coupon1{
	display:none;
	
	}
	

	
	#dispercentage{
	display:none;
	
	}
	#disamount{
	display:none;
	
	}
</style>