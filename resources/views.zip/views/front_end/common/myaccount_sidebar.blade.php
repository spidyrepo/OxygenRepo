<ul class="nav nav-tabs mb-6" role="tablist">
                            <li class="link-item">
                                <a href="{{url('/Accounts/Myaccount')}}" > <i class="w-icon-computer"></i> Dashboard</a>
                            </li>
                            <li class="link-item">
                                <a href="{{url('/Accounts/MyOrders')}}"> <i class="w-icon-cart"></i> Orders</a>
                            </li>
                            
                            <li class="link-item">
                                <a href="{{url('/Accounts/MyProfile')}}" ><i class="w-icon-user"></i> Profile</a>
                            </li>
                            <li class="link-item">
                                <a href="{{url('/Accounts/Usersettings')}}" ><i class="w-icon-tools"></i> Account details</a>
                            </li>
                            <li class="link-item">
                                <a href="{{url('/View_wishlist')}}" ><i class=" w-icon-heart"></i> Wishlist</a>
                            </li>
                            <li class="link-item">
                                <a href="{{url('/CusLogout')}}"  ><i class="w-icon-logout"></i> Logout</a>
                            </li>
                        </ul>