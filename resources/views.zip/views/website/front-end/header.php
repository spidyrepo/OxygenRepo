<body class="theme-color-29">
<!-- loader start -->
<!-- loader end -->
<!-- header start -->
<header class="header-style-5  border-style" id="sticky-header">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="main-menu">
                        <div class="menu-left">
                            <div class="navbar d-block d-xl-none">
                                
                            </div>
                            <div class="brand-logo">
                                <a href="index.html"><img src="../assets/img/logo/logo.png" class="img-fluid blur-up lazyloaded" alt=""></a>
                            </div>
                        </div>
                        <div>
                            <form class="form_search" role="form">
                                <input id="query search-autocomplete" type="search" placeholder="Search anything here..." class="nav-search nav-search-field" aria-expanded="true">
                                <button type="submit" name="nav-submit-button" class="btn-search">
                                    <i class="ti-search"></i>
                                </button>
                            </form>
                        </div>
                       <div class="header-tools top-header" style="background-color:transparent;">
                                    <ul class="header-dropdown">
                                        <li class="mobile-wishlist"><a href="#"><img
                                                    src="../assets/images/icon/heart-1.png" alt=""> </a></li>
                                        <li class="onhover-dropdown mobile-account">
                                            <img src="../assets/images/icon/user-1.png" alt="">
                                            <ul class="onhover-show-div">
                                                <li>
                                                    <a href="#" data-lng="en">
                                                        Login
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" data-lng="es">
                                                        Logout
                                                    </a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                        <div class="menu-right pull-right">
                           
                                <div class="icon-nav">
                                    <ul>
                                        <li class="onhover-div mobile-search d-xl-none d-inline-block">
                                            <div><img src="../assets/images/icon/search.png" onclick="openSearch()" class="img-fluid blur-up lazyload" alt=""> <i class="ti-search" onclick="openSearch()"></i></div>
                                        </li>
                                       
                                        <li class="onhover-div mobile-cart">
                                            <div><img src="../assets/images/icon/cart.png" class="img-fluid blur-up lazyloaded" alt=""> <i class="ti-shopping-cart"></i></div>
                                            <span class="cart_qty_cls">2</span>
                                            <ul class="show-div shopping-cart">
                                                <li>
                                                    <div class="media">
                                                        <a href="#"><img alt="" class="me-3" src="../assets/images/fashion/product/1.jpg"></a>
                                                        <div class="media-body">
                                                            <a href="#">
                                                                <h4>item name</h4>
                                                            </a>
                                                            <h4><span>1 x $ 299.00</span></h4>
                                                        </div>
                                                    </div>
                                                    <div class="close-circle"><a href="#"><i class="fa fa-times" aria-hidden="true"></i></a></div>
                                                </li>
                                                <li>
                                                    <div class="media">
                                                        <a href="#"><img alt="" class="me-3" src="../assets/images/fashion/product/2.jpg"></a>
                                                        <div class="media-body">
                                                            <a href="#">
                                                                <h4>item name</h4>
                                                            </a>
                                                            <h4><span>1 x $ 299.00</span></h4>
                                                        </div>
                                                    </div>
                                                    <div class="close-circle"><a href="#"><i class="fa fa-times" aria-hidden="true"></i></a></div>
                                                </li>
                                                <li>
                                                    <div class="total">
                                                        <h5>subtotal : <span>$299.00</span></h5>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="buttons"><a href="cart.html" class="view-cart">view
                                                            cart</a> <a href="#" class="checkout">checkout</a></div>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
									
                                </div>
								
                            </div>
							 
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="bottom-part bottom-light">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="main-nav-center">
                            <nav id="main-nav" class="text-start">
                                <div class="toggle-nav"><i class="fa fa-bars sidebar-bar"></i></div>
                                <ul id="main-menu" class="sm pixelstrap sm-horizontal" data-smartmenus-id="1653397609414521">
                                    <li>
                                        <div class="mobile-back text-end">Back<i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
                                    </li>
                                    <li><a href="index.html">Home</a></li>
                                    <li class="mega" id="hover-cls">
                                        <a href="#" class="has-submenu" id="sm-1653397609414521-1" aria-haspopup="true" aria-controls="sm-1653397609414521-2" aria-expanded="false">feature <div class="lable-nav">new</div><span class="sub-arrow"></span></a>
                                        <ul class="mega-menu full-mega-menu" id="sm-1653397609414521-2" role="group" aria-hidden="true" aria-labelledby="sm-1653397609414521-1" aria-expanded="false">
                                            <li>
                                                <div class="container">
                                                    <div class="row">
                                                        <div class="col mega-box">
                                                            <div class="link-section">
                                                                <div class="menu-title">
                                                                    <h5>add to cart</h5>
                                                                </div>
                                                                <div class="menu-content">
                                                                    <ul>
                                                                        <li><a href="nursery.html">cart modal
                                                                                popup</a></li>
                                                                        <li><a href="vegetables.html">qty.
                                                                                counter
                                                                                <i class="fa fa-bolt icon-trend" aria-hidden="true"></i></a>
                                                                        </li>
                                                                        <li><a href="bags.html">cart top</a>
                                                                        </li>
                                                                        <li><a href="shoes.html">cart bottom</a>
                                                                        </li>
                                                                        <li><a href="watch.html">cart left</a>
                                                                        </li>
                                                                        <li><a href="tools.html">cart right</a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col mega-box">
                                                            <div class="link-section">
                                                                <div class="menu-title">
                                                                    <h5>model</h5>
                                                                </div>
                                                                <div class="menu-content">
                                                                    <ul>
                                                                        <li><a href="index.html">Newsletter</a>
                                                                        </li>
                                                                        <li><a href="index.html">exit<i class="ms-2 fa fa-bolt icon-trend" aria-hidden="true"></i></a>
                                                                        </li>
                                                                        <li><a href="christmas.html">christmas</a>
                                                                        </li>
                                                                        <li><a href="furniture-3.html">black
                                                                                friday</a></li>
                                                                        <li><a href="fashion-4.html">cyber
                                                                                monday</a></li>
                                                                        <li><a href="marketplace-demo-3.html">new
                                                                                year</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col mega-box">
                                                            <div class="link-section">
                                                                <div class="menu-title">
                                                                    <h5>cookie bar</h5>
                                                                </div>
                                                                <div class="menu-content">
                                                                    <ul>
                                                                        <li><a href="index.html">bottom<i class="ms-2 fa fa-bolt icon-trend" aria-hidden="true"></i></a>
                                                                        </li>
                                                                        <li><a href="fashion-4.html">bottom
                                                                                left</a></li>
                                                                        <li><a href="bicycle.html">bottom
                                                                                right</a></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="menu-title mt-2">
                                                                    <h5>search</h5>
                                                                </div>
                                                                <div class="menu-content">
                                                                    <ul>
                                                                        <li><a href="marketplace-demo-2.html">ajax
                                                                                search<i class="ms-2 fa fa-bolt icon-trend" aria-hidden="true"></i></a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col mega-box">
                                                            <div class="link-section">
                                                                <div class="menu-title">
                                                                    <h5>invoice template</h5>
                                                                </div>
                                                                <div class="menu-content">
                                                                    <ul>
                                                                        <li><a target="_blank" href="invoice-1.html">invoice
                                                                                1</a></li>
                                                                        <li><a target="_blank" href="invoice-2.html">invoice
                                                                                2</a></li>
                                                                        <li><a target="_blank" href="invoice-3.html">invoice
                                                                                3</a></li>
                                                                        <li><a target="_blank" href="invoice-4.html">invoice
                                                                                4</a></li>
                                                                        <li><a target="_blank" href="invoice-5.html">invoice
                                                                                5</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col mega-box">
                                                            <div class="link-section">
                                                                <div class="menu-title">
                                                                    <h5>email template</h5>
                                                                </div>
                                                                <div class="menu-content">
                                                                    <ul>
                                                                        <li><a target="_blank" href="../email-template/email-order-success.html">order
                                                                                success</a></li>
                                                                        <li><a target="_blank" href="../email-template/email-order-success-two.html">order
                                                                                success 2</a></li>
                                                                        <li><a target="_blank" href="../email-template/email-template.html">email
                                                                                template</a></li>
                                                                        <li><a target="_blank" href="../email-template/email-template-two.html">email
                                                                                template 2</a></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="menu-title mt-2">
                                                                    <h5>elements</h5>
                                                                </div>
                                                                <div class="menu-content">
                                                                    <ul>
                                                                        <li><a href="elements.html">
                                                                                elements page<i class="ms-2 fa fa-bolt icon-trend" aria-hidden="true"></i>
                                                                            </a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <img src="../assets/images/menu-banner.jpg" class="img-fluid mega-img">
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="#" class="has-submenu" id="sm-1653397609414521-3" aria-haspopup="true" aria-controls="sm-1653397609414521-4" aria-expanded="false">shop<span class="sub-arrow"></span></a>
                                        <ul id="sm-1653397609414521-4" role="group" aria-hidden="true" aria-labelledby="sm-1653397609414521-3" aria-expanded="false" style="width: auto; min-width: 10em; display: none; max-width: 20em; top: auto; left: 0px; margin-left: 0px; margin-top: 0px;" class="sm-nowrap">
                                            <li><a href="category-page(top-filter).html">top filter<span class="new-tag">new</span></a></li>
                                            <li><a href="category-page(modern).html">modern<span class="new-tag">new</span></a></li>
                                            <li><a href="category-page.html">left sidebar</a></li>
                                            <li><a href="category-page(right).html">right sidebar</a></li>
                                            <li><a href="category-page(no-sidebar).html">no sidebar</a></li>
                                            <li><a href="category-page(sidebar-popup).html">sidebar popup</a>
                                            </li>
                                            <li><a href="category-page(metro).html">metro</a></li>
                                            <li><a href="category-page(full-width).html">full width</a></li>
                                            <li><a href="category-page(infinite-scroll).html">infinite
                                                    scroll</a></li>
                                            <li><a href="category-page(3-grid).html">three grid</a></li>
                                            <li><a href="category-page(6-grid).html">six grid</a></li>
                                            <li><a href="category-page(list-view).html">list view</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="#" class="has-submenu" id="sm-1653397609414521-5" aria-haspopup="true" aria-controls="sm-1653397609414521-6" aria-expanded="false">product<span class="sub-arrow"></span></a>
                                        <ul id="sm-1653397609414521-6" role="group" aria-hidden="true" aria-labelledby="sm-1653397609414521-5" aria-expanded="false">
                                            <li><a href="product-page(360-view).html">360 view <span class="new-tag">new</span></a></li>
                                            <li><a href="product-page(video-thumbnail).html">video
                                                    thumbnail<span class="new-tag">new</span></a></li>
                                            <li>
                                                <a href="#" class="has-submenu" id="sm-1653397609414521-7" aria-haspopup="true" aria-controls="sm-1653397609414521-8" aria-expanded="false">sidebar<span class="sub-arrow"></span></a>
                                                <ul id="sm-1653397609414521-8" role="group" aria-hidden="true" aria-labelledby="sm-1653397609414521-7" aria-expanded="false">
                                                    <li><a href="product-page.html">left sidebar</a></li>
                                                    <li><a href="product-page(right-sidebar).html">right
                                                            sidebar</a>
                                                    </li>
                                                    <li><a href="product-page(no-sidebar).html">no sidebar</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="#" class="has-submenu" id="sm-1653397609414521-9" aria-haspopup="true" aria-controls="sm-1653397609414521-10" aria-expanded="false">thumbnail image<span class="sub-arrow"></span></a>
                                                <ul id="sm-1653397609414521-10" role="group" aria-hidden="true" aria-labelledby="sm-1653397609414521-9" aria-expanded="false">
                                                    <li><a href="product-page(left-image).html">left image</a>
                                                    </li>
                                                    <li><a href="product-page(right-image).html">right image</a>
                                                    </li>
                                                    <li><a href="product-page(image-outside).html">image
                                                            outside</a></li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="#" class="has-submenu" id="sm-1653397609414521-11" aria-haspopup="true" aria-controls="sm-1653397609414521-12" aria-expanded="false">three column<span class="sub-arrow"></span></a>
                                                <ul id="sm-1653397609414521-12" role="group" aria-hidden="true" aria-labelledby="sm-1653397609414521-11" aria-expanded="false">
                                                    <li><a href="product-page(3-col-left).html">thumbnail
                                                            left</a>
                                                    </li>
                                                    <li><a href="product-page(3-col-right).html">thumbnail
                                                            right</a>
                                                    </li>
                                                    <li><a href="product-page(3-column).html">thubnail
                                                            bottom</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li><a href="product-page(4-image).html">four image</a></li>
                                            <li><a href="product-page(sticky).html">sticky</a></li>
                                            <li><a href="product-page(accordian).html">accordian</a></li>
                                            <li><a href="product-page(bundle).html">bundle</a></li>
                                            <li><a href="product-page(image-swatch).html">image swatch </a></li>
                                            <li><a href="product-page(vertical-tab).html">vertical tab</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#" class="has-submenu" id="sm-1653397609414521-13" aria-haspopup="true" aria-controls="sm-1653397609414521-14" aria-expanded="false">pages<span class="sub-arrow"></span></a>
                                        <ul id="sm-1653397609414521-14" role="group" aria-hidden="true" aria-labelledby="sm-1653397609414521-13" aria-expanded="false">
                                            <li>
                                                <a href="#" class="has-submenu" id="sm-1653397609414521-15" aria-haspopup="true" aria-controls="sm-1653397609414521-16" aria-expanded="false">vendor<span class="sub-arrow"></span></a>
                                                <ul id="sm-1653397609414521-16" role="group" aria-hidden="true" aria-labelledby="sm-1653397609414521-15" aria-expanded="false">
                                                    <li><a href="vendor-dashboard.html">vendor dashboard</a>
                                                    </li>
                                                    <li><a href="vendor-profile.html">vendor profile</a></li>
                                                    <li><a href="become-vendor.html">become vendor</a></li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="#" class="has-submenu" id="sm-1653397609414521-17" aria-haspopup="true" aria-controls="sm-1653397609414521-18" aria-expanded="false">account<span class="sub-arrow"></span></a>
                                                <ul id="sm-1653397609414521-18" role="group" aria-hidden="true" aria-labelledby="sm-1653397609414521-17" aria-expanded="false">
                                                    <li><a href="wishlist.html">wishlist</a></li>
                                                    <li><a href="cart.html">cart</a></li>
                                                    <li><a href="dashboard.html">Dashboard</a></li>
                                                    <li><a href="login.html">login</a></li>
                                                    <li><a href="register.html">register</a></li>
                                                    <li><a href="contact.html">contact</a></li>
                                                    <li><a href="forget_pwd.html">forget password</a></li>
                                                    <li><a href="profile.html">profile</a></li>
                                                    <li><a href="checkout.html">checkout</a></li>
                                                    <li><a href="order-success.html">order success</a></li>
                                                    <li><a href="order-tracking.html">order tracking<span class="new-tag">new</span></a></li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="#" class="has-submenu" id="sm-1653397609414521-19" aria-haspopup="true" aria-controls="sm-1653397609414521-20" aria-expanded="false">portfolio<span class="sub-arrow"></span></a>
                                                <ul id="sm-1653397609414521-20" role="group" aria-hidden="true" aria-labelledby="sm-1653397609414521-19" aria-expanded="false">
                                                    <li><a href="" class="has-submenu" id="sm-1653397609414521-21" aria-haspopup="true" aria-controls="sm-1653397609414521-22" aria-expanded="false">grid<span class="sub-arrow"></span></a>
                                                        <ul id="sm-1653397609414521-22" role="group" aria-hidden="true" aria-labelledby="sm-1653397609414521-21" aria-expanded="false">
                                                            <li><a href="grid-2-col.html">grid
                                                                    2</a></li>
                                                            <li><a href="grid-3-col.html">grid
                                                                    3</a></li>
                                                            <li><a href="grid-4-col.html">grid
                                                                    4</a></li>
                                                        </ul>
                                                    </li>
                                                    <li><a href="" class="has-submenu" id="sm-1653397609414521-23" aria-haspopup="true" aria-controls="sm-1653397609414521-24" aria-expanded="false">masonry<span class="sub-arrow"></span></a>
                                                        <ul id="sm-1653397609414521-24" role="group" aria-hidden="true" aria-labelledby="sm-1653397609414521-23" aria-expanded="false">
                                                            <li><a href="masonary-2-grid.html">grid 2</a></li>
                                                            <li><a href="masonary-3-grid.html">grid 3</a></li>
                                                            <li><a href="masonary-4-grid.html">grid 4</a></li>
                                                            <li><a href="masonary-fullwidth.html">full width</a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li><a href="about-page.html">about us</a></li>
                                            <li><a href="search.html">search</a></li>
                                            <li><a href="review.html">review</a>
                                            </li>
                                            <li>
                                                <a href="#" class="has-submenu" id="sm-1653397609414521-25" aria-haspopup="true" aria-controls="sm-1653397609414521-26" aria-expanded="false">compare<span class="sub-arrow"></span></a>
                                                <ul id="sm-1653397609414521-26" role="group" aria-hidden="true" aria-labelledby="sm-1653397609414521-25" aria-expanded="false">
                                                    <li><a href="compare.html">compare</a></li>
                                                    <li><a href="compare-2.html">compare-2</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="collection.html">collection</a></li>
                                            <li><a href="lookbook.html">lookbook</a></li>
                                            <li><a href="sitemap.html">site map</a>
                                            </li>
                                            <li><a href="404.html">404</a></li>
                                            <li><a href="coming-soon.html">coming soon</a></li>
                                            <li><a href="faq.html">FAQ</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="#" class="has-submenu" id="sm-1653397609414521-27" aria-haspopup="true" aria-controls="sm-1653397609414521-28" aria-expanded="false">blog<span class="sub-arrow"></span></a>
                                        <ul id="sm-1653397609414521-28" role="group" aria-hidden="true" aria-labelledby="sm-1653397609414521-27" aria-expanded="false">
                                            <li><a href="blog-page.html">left sidebar</a></li>
                                            <li><a href="blog(right-sidebar).html">right sidebar</a></li>
                                            <li><a href="blog(no-sidebar).html">no sidebar</a></li>
                                            <li><a href="blog-details.html">blog details</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
    </header>
<!-- header end -->
