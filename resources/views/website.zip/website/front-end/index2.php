  <?php include('newhead.php')?>
 <?php include('newheader.php')?>


    <!-- Home slider -->
    <section class="p-0">
        <div class="slider-animate home-slider">
            <div>
                <div class="home height-apply p-bottom">
                    <img src="../assets/img/banner/1.jpg" alt="" class="bg-img ">
                    <div class="container-lg">
                        <div class="row">
                            <div class="col">
                                <div class="slider-contain height-apply">
                                    <div>
                                        <h4>save 30%</h4>
                                        <h1>special products</h1><a href="#"
                                            class="btn btn-solid btn-gradient animated">shop
                                            now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			 <div>
                <div class="home height-apply p-bottom">
                    <img src="../assets/img/banner/2.jpg" alt="" class="bg-img ">
                    <div class="container-lg">
                        <div class="row">
                            <div class="col">
                                <div class="slider-contain height-apply">
                                    <div>
                                        <h4>save 30%</h4>
                                        <h1>special products</h1><a href="#"
                                            class="btn btn-solid btn-gradient animated">shop
                                            now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			 <div>
                <div class="home height-apply p-bottom">
                    <img src="../assets/img/banner/3.jpg" alt="" class="bg-img ">
                    <div class="container-lg">
                        <div class="row">
                            <div class="col">
                                <div class="slider-contain height-apply">
                                    <div>
                                        <h4>save 30%</h4>
                                        <h1>special products</h1><a href="#"
                                            class="btn btn-solid btn-gradient animated">shop
                                            now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			 <div>
                <div class="home height-apply p-bottom">
                    <img src="../assets/img/banner/4.jpg" alt="" class="bg-img ">
                    <div class="container-lg">
                        <div class="row">
                            <div class="col">
                                <div class="slider-contain height-apply">
                                    <div>
                                        <h4>save 30%</h4>
                                        <h1>special products</h1><a href="#"
                                            class="btn btn-solid btn-gradient animated">shop
                                            now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div class="home height-apply p-bottom">
                    <img src="../assets/img/banner/5.jpg" alt="" class="bg-img ">
                    <div class="container-lg">
                        <div class="row">
                            <div class="col">
                                <div class="slider-contain height-apply">
                                    <div>
                                        <h4>save 30%</h4>
                                        <h1>special products</h1><a href="#"
                                            class="btn btn-solid btn-gradient animated">shop
                                            now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Home slider end -->


    <!-- category section start -->
    <section>
        <div class="container container-lg">
            <div class="row margin-default ratio_square">
                <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                    <a href="#">
                        <div class="gradient-category">
                            <div class="gradient-border">
                                <div class="img-sec">
                                    <img src="../assets/images/fashion/category/1.png" class="img-fluid" alt="">
                                </div>
                            </div>
                            <h4>Top wear</h4>
                        </div>
                    </a>
                </div>
                <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                    <a href="#">
                        <div class="gradient-category hover-effect">
                            <div class="gradient-border">
                                <div class="img-sec">
                                    <img src="../assets/images/fashion/category/4.png" class="img-fluid" alt="">
                                </div>
                            </div>
                            <h4>dresses</h4>
                        </div>
                    </a>
                </div>
                <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                    <a href="#">
                        <div class="gradient-category">
                            <div class="gradient-border">
                                <div class="img-sec">
                                    <img src="../assets/images/fashion/category/3.png" class="img-fluid" alt="">
                                </div>
                            </div>
                            <h4>bottom</h4>
                        </div>
                    </a>
                </div>
                <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                    <a href="#">
                        <div class="gradient-category">
                            <div class="gradient-border">
                                <div class="img-sec">
                                    <img src="../assets/images/fashion/category/2.png" class="img-fluid" alt="">
                                </div>
                            </div>
                            <h4>inner/sleep</h4>
                        </div>
                    </a>
                </div>
                <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                    <a href="#">
                        <div class="gradient-category">
                            <div class="gradient-border">
                                <div class="img-sec">
                                    <img src="../assets/images/fashion/category/5.png" class="img-fluid" alt="">
                                </div>
                            </div>
                            <h4>footwear</h4>
                        </div>
                    </a>
                </div>
                <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                    <a href="#">
                        <div class="gradient-category">
                            <div class="gradient-border">
                                <div class="img-sec">
                                    <img src="../assets/images/fashion/category/6.png" class="img-fluid" alt="">
                                </div>
                            </div>
                            <h4>sports/active</h4>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- category section end -->


    <!-- collection banner -->
    <section class="pb-0 ratio2_1">
        <div class="container container-lg">
            <div class="row partition2">
                <div class="col-md-6">
                    <a href="#">
                        <div class="collection-banner p-right text-center">
                            <div class="img-part">
                                <img src="../assets/img/banner/3.jpg"
                                    class="img-fluid  bg-img" alt="">
                            </div>
                            <div class="contain-banner">
                                <div>
                                    <h4>save 30%</h4>
                                    <h2>men</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6">
                    <a href="#">
                        <div class="collection-banner p-right text-center">
                            <div class="img-part">
                                <img src="../assets/img/banner/2.jpg"
                                    class="img-fluid  bg-img" alt="">
                            </div>
                            <div class="contain-banner">
                                <div>
                                    <h4>save 60%</h4>
                                    <h2>women</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- collection banner end -->


    <!-- collection banner start -->
    <section class="banner-goggles ratio2_1 banner-padding" style="display:none;">
        <div class="container container-lg">
            <div class="row partition3">
                <div class="col-md-4">
                    <a href="#">
                        <div class="collection-banner p-right text-end">
                            <div class="img-part">
                                <img src="../assets/images/gradient/banner/1.jpg"
                                    class="img-fluid  bg-img" alt="">
                            </div>
                            <div class="contain-banner banner-3">
                                <div>
                                    <h4>10% off</h4>
                                    <h2>speaker</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="#">
                        <div class="collection-banner p-right text-end">
                            <div class="img-part">
                                <img src="../assets/images/gradient/banner/2.jpg"
                                    class="img-fluid  bg-img" alt="">
                            </div>
                            <div class="contain-banner banner-3">
                                <div>
                                    <h4>10% off</h4>
                                    <h2>earplug</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="#">
                        <div class="collection-banner p-right text-end">
                            <div class="img-part">
                                <img src="../assets/images/gradient/banner/3.jpg"
                                    class="img-fluid  bg-img" alt="">
                            </div>
                            <div class="contain-banner banner-3">
                                <div>
                                    <h4>50% off</h4>
                                    <h2>best deal</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- collection banner end -->


    <!-- Tab product -->
    <div class="title1 title-fancy section-t-space">
        <h4>exclusive products</h4>
        <h2 class="title-inner1 title-gradient">special products</h2>
    </div>
    <section class="section-b-space pt-0 ratio_asos">
        <div class="container container-lg">
            <div class="row">
                <div class="col">
                    <div class="theme-tab">
                        <ul class="tabs tab-title">
                            <li class="current"><a href="tab-4">New Products</a></li>
                            <li class=""><a href="tab-5">Featured Products</a></li>
                            <li class=""><a href="tab-6">Best Sellers</a></li>
                        </ul>
                        <div class="tab-content-cls">
                            <div id="tab-4" class="tab-content active default">
                                <div class="no-slider row">
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/1.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <div class="lable-block"><span class="lable-gradient">new</span> <span
                                                    class="lable4">on sale</span></div>
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/2.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500.00</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/3.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <div class="lable-block"><span class="lable-gradient">new</span> <span
                                                    class="lable4">on sale</span></div>
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/4.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <div class="lable-block"><span class="lable-gradient">new</span> <span
                                                    class="lable4">on sale</span></div>
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/top/1/1.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Top</h6>
                                                </a>
                                                <h4>Rs 399</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/top/2/1.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Short Top</h6>
                                                </a>
                                                <h4>Rs 599</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <div class="lable-block"><span class="lable-gradient">new</span> <span
                                                    class="lable4">on sale</span></div>
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/top/3/1.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Top</h6>
                                                </a>
                                                <h4>Rs 599</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/8.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <div class="lable-block"><span class="lable-gradient">new</span> <span
                                                    class="lable4">on sale</span></div>
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/top/4/1.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Long Top</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/11.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="tab-5" class="tab-content">
                                <div class="no-slider row">
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/1.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <div class="lable-block"><span class="lable-gradient">new</span> <span
                                                    class="lable4">on sale</span></div>
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/2.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500.00</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/3.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <div class="lable-block"><span class="lable-gradient">new</span> <span
                                                    class="lable4">on sale</span></div>
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/4.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <div class="lable-block"><span class="lable-gradient">new</span> <span
                                                    class="lable4">on sale</span></div>
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/top/1/1.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Top</h6>
                                                </a>
                                                <h4>Rs 399</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/top/2/1.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Short Top</h6>
                                                </a>
                                                <h4>Rs 599</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <div class="lable-block"><span class="lable-gradient">new</span> <span
                                                    class="lable4">on sale</span></div>
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/top/3/1.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Top</h6>
                                                </a>
                                                <h4>Rs 599</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/8.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <div class="lable-block"><span class="lable-gradient">new</span> <span
                                                    class="lable4">on sale</span></div>
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/top/4/1.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Long Top</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/11.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="tab-6" class="tab-content">
                               <div class="no-slider row">
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/1.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <div class="lable-block"><span class="lable-gradient">new</span> <span
                                                    class="lable4">on sale</span></div>
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/2.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500.00</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/3.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <div class="lable-block"><span class="lable-gradient">new</span> <span
                                                    class="lable4">on sale</span></div>
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/4.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <div class="lable-block"><span class="lable-gradient">new</span> <span
                                                    class="lable4">on sale</span></div>
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/top/1/1.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Top</h6>
                                                </a>
                                                <h4>Rs 399</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/top/2/1.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Short Top</h6>
                                                </a>
                                                <h4>Rs 599</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <div class="lable-block"><span class="lable-gradient">new</span> <span
                                                    class="lable4">on sale</span></div>
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/top/3/1.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Top</h6>
                                                </a>
                                                <h4>Rs 599</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/8.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <div class="lable-block"><span class="lable-gradient">new</span> <span
                                                    class="lable4">on sale</span></div>
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/top/4/1.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Long Top</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-box">
                                        <div class="img-wrapper">
                                            <a href="product_view.php"><img
                                                    src="../assets/img/product/saree/11.jpg"
                                                    class="img-fluid  bg-img" alt=""></a>
                                            <div class="cart-box cart-box-bottom">
                                                <button data-bs-toggle="modal" data-bs-target="#addtocart"
                                                    title="Add to cart"><i class="ti-shopping-cart"></i></button> <a
                                                    href="javascript:void(0)" title="Add to Wishlist"><i
                                                        class="ti-heart" aria-hidden="true"></i></a> <a href="#"
                                                    data-bs-toggle="modal" data-bs-target="#quick-view"
                                                    title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                               
                                            </div>
                                        </div>
                                        <div class="product-detail">
                                            <div class="detail-inline">
                                                <a href="product_view.php">
                                                    <h6>Saree</h6>
                                                </a>
                                                <h4>Rs 500</h4>
                                            </div>
                                            <ul class="color-variant pt-0">
                                                <li class="bg-light0"></li>
                                                <li class="bg-light1"></li>
                                                <li class="bg-light2"></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Tab product end -->


    <!-- category section start -->
    
    <!-- category section end -->


    <!-- product slider -->
    <section class="ratio_asos gradient-slider" style="display:none;">
        <div class="container container-lg">
            <div class="row">
                <div class="col-12">
                    <div class="title1 title-fancy">
                        <h4>exclusive products</h4>
                        <h2 class="title-inner1 title-gradient">special products</h2>
                    </div>
                </div>
                <div class="col">
                    <div class="product-5 product-m no-arrow">
                        <div class="product-box">
                            <div class="img-wrapper">
                                <a href="product_view.php"><img
                                        src="../assets/images/gradient/product/4.jpg"
                                        class="img-fluid  bg-img" alt=""></a>
                                <div class="cart-box cart-box-bottom">
                                    <button data-bs-toggle="modal" data-bs-target="#addtocart" title="Add to cart"><i
                                            class="ti-shopping-cart"></i></button> <a href="javascript:void(0)"
                                        title="Add to Wishlist"><i class="ti-heart" aria-hidden="true"></i></a> <a
                                        href="#" data-bs-toggle="modal" data-bs-target="#quick-view"
                                        title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                    <a href="compare.html" title="Compare"><i class="ti-reload"
                                            aria-hidden="true"></i></a>
                                </div>
                            </div>
                            <div class="product-detail">
                                <div class="detail-inline">
                                    <a href="product_view.php">
                                        <h6>Saree</h6>
                                    </a>
                                    <h4>Rs 500</h4>
                                </div>
                                <ul class="color-variant pt-0">
                                    <li class="bg-light0"></li>
                                    <li class="bg-light1"></li>
                                    <li class="bg-light2"></li>
                                </ul>
                            </div>
                        </div>
                        <div class="product-box">
                            <div class="img-wrapper">
                                <div class="lable-block"><span class="lable-gradient">new</span> <span class="lable4">on
                                        sale</span></div>
                                <a href="product_view.php"><img
                                        src="../assets/images/gradient/product/6.jpg"
                                        class="img-fluid  bg-img" alt=""></a>
                                <div class="cart-box cart-box-bottom">
                                    <button data-bs-toggle="modal" data-bs-target="#addtocart" title="Add to cart"><i
                                            class="ti-shopping-cart"></i></button> <a href="javascript:void(0)"
                                        title="Add to Wishlist"><i class="ti-heart" aria-hidden="true"></i></a> <a
                                        href="#" data-bs-toggle="modal" data-bs-target="#quick-view"
                                        title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                    <a href="compare.html" title="Compare"><i class="ti-reload"
                                            aria-hidden="true"></i></a>
                                </div>
                            </div>
                            <div class="product-detail">
                                <div class="detail-inline">
                                    <a href="product_view.php">
                                        <h6>Saree</h6>
                                    </a>
                                    <h4>Rs 500</h4>
                                </div>
                                <ul class="color-variant pt-0">
                                    <li class="bg-light0"></li>
                                    <li class="bg-light1"></li>
                                    <li class="bg-light2"></li>
                                </ul>
                            </div>
                        </div>
                        <div class="product-box">
                            <div class="img-wrapper">
                                <a href="product_view.php"><img
                                        src="../assets/images/gradient/product/2.jpg"
                                        class="img-fluid  bg-img" alt=""></a>
                                <div class="cart-box cart-box-bottom">
                                    <button data-bs-toggle="modal" data-bs-target="#addtocart" title="Add to cart"><i
                                            class="ti-shopping-cart"></i></button> <a href="javascript:void(0)"
                                        title="Add to Wishlist"><i class="ti-heart" aria-hidden="true"></i></a> <a
                                        href="#" data-bs-toggle="modal" data-bs-target="#quick-view"
                                        title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                    <a href="compare.html" title="Compare"><i class="ti-reload"
                                            aria-hidden="true"></i></a>
                                </div>
                            </div>
                            <div class="product-detail">
                                <div class="detail-inline">
                                    <a href="product_view.php">
                                        <h6>Saree</h6>
                                    </a>
                                    <h4>Rs 500</h4>
                                </div>
                                <ul class="color-variant pt-0">
                                    <li class="bg-light0"></li>
                                    <li class="bg-light1"></li>
                                    <li class="bg-light2"></li>
                                </ul>
                            </div>
                        </div>
                        <div class="product-box">
                            <div class="img-wrapper">
                                <div class="lable-block"><span class="lable-gradient">new</span> <span class="lable4">on
                                        sale</span></div>
                                <a href="product_view.php"><img
                                        src="../assets/images/gradient/product/5.jpg"
                                        class="img-fluid  bg-img" alt=""></a>
                                <div class="cart-box cart-box-bottom">
                                    <button data-bs-toggle="modal" data-bs-target="#addtocart" title="Add to cart"><i
                                            class="ti-shopping-cart"></i></button> <a href="javascript:void(0)"
                                        title="Add to Wishlist"><i class="ti-heart" aria-hidden="true"></i></a> <a
                                        href="#" data-bs-toggle="modal" data-bs-target="#quick-view"
                                        title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                    <a href="compare.html" title="Compare"><i class="ti-reload"
                                            aria-hidden="true"></i></a>
                                </div>
                            </div>
                            <div class="product-detail">
                                <div class="detail-inline">
                                    <a href="product_view.php">
                                        <h6>Saree</h6>
                                    </a>
                                    <h4>Rs 500</h4>
                                </div>
                                <ul class="color-variant pt-0">
                                    <li class="bg-light0"></li>
                                    <li class="bg-light1"></li>
                                    <li class="bg-light2"></li>
                                </ul>
                            </div>
                        </div>
                        <div class="product-box">
                            <div class="img-wrapper">
                                <div class="lable-block"><span class="lable-gradient">new</span> <span class="lable4">on
                                        sale</span></div>
                                <a href="product_view.php"><img
                                        src="../assets/images/gradient/product/8.jpg"
                                        class="img-fluid  bg-img" alt=""></a>
                                <div class="cart-box cart-box-bottom">
                                    <button data-bs-toggle="modal" data-bs-target="#addtocart" title="Add to cart"><i
                                            class="ti-shopping-cart"></i></button> <a href="javascript:void(0)"
                                        title="Add to Wishlist"><i class="ti-heart" aria-hidden="true"></i></a> <a
                                        href="#" data-bs-toggle="modal" data-bs-target="#quick-view"
                                        title="Quick View"><i class="ti-search" aria-hidden="true"></i></a>
                                    <a href="compare.html" title="Compare"><i class="ti-reload"
                                            aria-hidden="true"></i></a>
                                </div>
                            </div>
                            <div class="product-detail">
                                <div class="detail-inline">
                                    <a href="product_view.php">
                                        <h6>Saree</h6>
                                    </a>
                                    <h4>Rs 500</h4>
                                </div>
                                <ul class="color-variant pt-0">
                                    <li class="bg-light0"></li>
                                    <li class="bg-light1"></li>
                                    <li class="bg-light2"></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- product slider -->


    <!-- deal zone section start -->
    <section class="section-b-space">
        <div class="container-lg container">
            <div class="row margin-default ratio_square ">
                <div class="col-xl-2 col-md-3 col-sm-4 col-4">
                    <a href="#">
                        <div class="deal-category">
                            <img src="../assets/images/gradient/deal-bg/1.jpg" class="img-fluid w-100" alt="">
                            <div class="deal-content">
                                <div>
                                    <h2>40%</h2>
                                    <h2>60%</h2>
                                    <h2 class="mb-0">off</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-2 col-md-3 col-sm-4 col-4">
                    <a href="#">
                        <div class="deal-category">
                            <img src="../assets/images/gradient/deal-bg/2.jpg" class="img-fluid w-100" alt="">
                            <div class="deal-content">
                                <div>
                                    <h2>Flat</h2>
                                    <h2>60%</h2>
                                    <h2 class="mb-0">off</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-2 col-md-3 col-sm-4 col-4">
                    <a href="#">
                        <div class="deal-category">
                            <img src="../assets/images/gradient/deal-bg/6.jpg" class="img-fluid w-100" alt="">
                            <div class="deal-content">
                                <div>
                                    <h2>free</h2>
                                    <h2>Ship.</h2>
                                    <h2 class="mb-0">zone</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-2 col-md-3 col-sm-4 col-4">
                    <a href="#">
                        <div class="deal-category">
                            <img src="../assets/images/gradient/deal-bg/3.jpg" class="img-fluid w-100" alt="">
                            <div class="deal-content">
                                <div>
                                    <h2>Buy 1</h2>
                                    <h2>Get 1</h2>
                                    <h2 class="mb-0">Free</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-2 col-md-3 col-sm-4 col-4">
                    <a href="#">
                        <div class="deal-category">
                            <img src="../assets/images/gradient/deal-bg/4.jpg" class="img-fluid w-100" alt="">
                            <div class="deal-content">
                                <div>
                                    <h2>upto</h2>
                                    <h2>40%</h2>
                                    <h2 class="mb-0">off</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-2 col-md-3 col-sm-4 col-4">
                    <a href="#">
                        <div class="deal-category">
                            <img src="../assets/images/gradient/deal-bg/5.jpg" class="img-fluid w-100" alt="">
                            <div class="deal-content">
                                <div>
                                    <h2>Min</h2>
                                    <h2>20%</h2>
                                    <h2 class="mb-0">off</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>
   

    <!-- footer -->
    <?php include('newfooter.php')?>