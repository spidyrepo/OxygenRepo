<!--<script src="jquery-3.6.3.min.js"></script>-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>