 <!-- latest jquery-->
 <script src="{{ asset('frontend_assets/js/jquery-3.3.1.min.js') }}"></script>

 <!-- slick js-->
 <script src="{{ asset('frontend_assets/js/slick.js')}}"></script>
 <script src="{{ asset('frontend_assets/js/slick-animation.min.js') }}"></script>

 <!-- wow js-->
 <script src="{{ asset('frontend_assets/js/wow.min.js')}}"></script>

 <!-- menu js-->
 <script src="{{ asset('frontend_assets/js/menu.js')}}"></script>

 <!-- lazyload js-->
 <script src="{{ asset('frontend_assets/js/lazysizes.min.js')}}"></script>

 <!-- Bootstrap js-->
 <script src="{{ asset('frontend_assets/js/bootstrap.bundle.min.js')}}"></script>

 <!-- Bootstrap Notification js-->
 <script src="{{ asset('frontend_assets/js/bootstrap-notify.min.js')}}"></script>

 <!-- Theme js-->
 <script src="{{ asset('frontend_assets/js/theme-setting.js')}}"></script>
 <script src="{{ asset('frontend_assets/js/color-setting.js')}}"></script>
 <script src="{{ asset('frontend_assets/js/script.js') }}"></script>
 <script src="{{ asset('frontend_assets/js/custom-slick-animated.js') }}"></script>

 <!--<script src="{{ asset('frontend_assets/js/cart.js') }}"></script>-->