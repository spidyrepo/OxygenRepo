<?php

namespace App\Models\ViewModels;

class CommonReturnVM
{
    public  $statusCode;
    public  $statusMsg;
    public  $data;
}
