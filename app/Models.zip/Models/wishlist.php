<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class wishlist extends Model
{
    
    protected $table = 'ecom_wishlist';   

    /*public function productname()
    {
        return $this->belongsTo('App\Models\Ecom_Product','ecom_product_id','ecom_product_id');
    }*/
}


