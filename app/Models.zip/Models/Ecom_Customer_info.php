<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ecom_Customer_info extends Model
{
    protected $table = 'ecom_customer_info';

    public $fillable = [];
}